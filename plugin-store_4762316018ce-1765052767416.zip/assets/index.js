// Fallback: Source files will be built by Vite during deployment
// This is a temporary fallback - the plugin should be built with Vite for production

console.warn('[Plugin] Using fallback build - please build with Vite for production')

// Export the entry point
export * from './src/index.tsx'
